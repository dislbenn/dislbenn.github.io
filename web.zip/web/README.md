# Web-Crawler
Web crawler designed in Python, to search the web for products that impact seniors, and return a list of those products and rating details.
